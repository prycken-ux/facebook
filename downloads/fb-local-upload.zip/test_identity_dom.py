"""Exercise the real header guard in Chromium using local HTML, without Facebook login."""
import unittest

from playwright.sync_api import sync_playwright

import fb_upload as upload


class HeaderDOMChecks(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.playwright = sync_playwright().start()
        cls.browser = cls.playwright.chromium.launch(executable_path="/usr/bin/chromium", headless=True)
        cls.page = cls.browser.new_page()

    @classmethod
    def tearDownClass(cls):
        cls.browser.close()
        cls.playwright.stop()

    def proof(self, header_controls="", sidebar="", feed=""):
        self.page.set_content(
            '<div><aside>Manage Page' + sidebar + '</aside><main><section>'
            '<div><h1>Example Page</h1></div>' + header_controls + '</section>' + feed + '</main></div>')
        return self.page.get_by_role("heading", name="Example Page", exact=True).evaluate(upload.HEADER_MANAGEMENT_JS)

    def test_sidebar_dashboard_and_sidebar_edit_do_not_prove_identity(self):
        self.assertIsNone(self.proof(sidebar='<button>Professional dashboard</button><button>Edit</button>'))

    def test_dashboard_in_header_passes_without_edit(self):
        for control in ('<button>Professional dashboard</button>', '<a href="/dashboard">Professional dashboard</a>'):
            with self.subTest(control=control):
                self.assertEqual(self.proof(control), "active_page_header_management_control")

    def test_feed_controls_are_not_header_controls(self):
        self.assertIsNone(self.proof(feed='<div role="feed"><article role="article"><button>Edit</button></article></div>'))

    def test_hidden_or_disabled_header_buttons_do_not_count(self):
        for attr in ('disabled', 'aria-disabled="true"', 'style="display:none"', 'style="visibility:hidden"'):
            with self.subTest(attr=attr):
                self.assertIsNone(self.proof('<button ' + attr + '>Professional dashboard</button>'))

    def test_personal_view_header_controls_do_not_count(self):
        self.assertIsNone(self.proof('<button>Message</button><button>Follow</button><button>Switch Now</button>'))


if __name__ == "__main__":
    unittest.main()
