import contextlib
import io
import unittest
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

import fb_upload as upload


class Locator:
    def __init__(self, visible=False, enabled=True, count=1):
        self.visible, self.enabled, self.size = visible, enabled, count
        self.first = self
        self.on_click = lambda: None
        self.clicked = False

    def count(self):
        return self.size

    def is_visible(self):
        return self.visible

    def click(self):
        self.clicked = True
        self.on_click()


class Assertion:
    def __init__(self, locator):
        self.locator = locator

    def to_be_visible(self, **kwargs):
        if not self.locator.visible:
            raise RuntimeError("not visible")

    def not_to_be_visible(self, **kwargs):
        if self.locator.visible:
            raise RuntimeError("still visible")

    def to_be_enabled(self, **kwargs):
        if not self.locator.enabled:
            raise RuntimeError("disabled")


class IdentityChecks(unittest.TestCase):
    def setUp(self):
        self.entry = {"name": "Example Page", "url": "https://www.facebook.com/profile.php?id=1001"}
        self.heading = Locator(visible=True)
        self.switch = Locator(visible=True)
        self.banner = Locator(visible=True)
        self.edit = Locator(visible=False)
        self.page = MagicMock()
        self.page.url = self.entry["url"]
        self.page.context.cookies.return_value = []
        self.heading.evaluate = lambda script: ("active_page_header_management_control"
                                                if self.edit.visible and self.edit.enabled else None)
        def role(role_kind, **kwargs):
            if role_kind == "heading":
                return self.heading
            pattern = kwargs["name"].pattern
            return self.switch if "Switch Now" in pattern else self.edit
        self.page.get_by_role.side_effect = role
        self.page.get_by_text.side_effect = lambda pattern: self.switch if "Switch Now" in pattern.pattern else self.banner
        self.expect = patch("playwright.sync_api.expect", side_effect=Assertion)
        self.expect.start()
        self.silence = contextlib.redirect_stdout(io.StringIO())
        self.silence.__enter__()

    def tearDown(self):
        self.silence.__exit__(None, None, None)
        self.expect.stop()

    def test_visible_switch_banner_requires_switch_and_active_edit_control(self):
        def switched():
            self.switch.visible = False
            self.banner.visible = False
            self.edit.visible = True
        self.switch.on_click = switched
        result = upload.ensure_page_identity(self.page, self.entry)
        self.assertTrue(result["switched"])
        self.assertTrue(self.switch.clicked)

    def test_sidebar_manage_page_alone_does_not_allow_upload(self):
        self.switch.size = 0
        self.banner.visible = False
        self.edit.visible = False
        with self.assertRaises(RuntimeError):
            upload.prepare_reel(self.page, self.entry, SimpleNamespace(resolve=lambda: "video.mp4"), "caption")
        self.assertFalse(any(call.args[0] == "form" for call in self.page.get_by_role.call_args_list))

    def test_unsuccessful_switch_stops_before_video_selection(self):
        with self.assertRaises(RuntimeError):
            upload.prepare_reel(self.page, self.entry, None, "caption")
        self.assertTrue(self.switch.clicked)
        self.assertFalse(any(call.args[0] == "form" for call in self.page.get_by_role.call_args_list))

    def test_existing_active_page_is_not_toggled_to_other_identity(self):
        self.switch.size = 0
        self.switch.visible = False
        self.banner.visible = False
        self.edit.visible = True
        result = upload.ensure_page_identity(self.page, self.entry)
        self.assertFalse(result["switched"])
        self.assertFalse(self.switch.clicked)

    def test_same_name_on_wrong_page_url_is_rejected(self):
        self.page.url = "https://www.facebook.com/profile.php?id=9999"
        with self.assertRaises(RuntimeError):
            upload.ensure_page_identity(self.page, self.entry)
        self.assertFalse(self.switch.clicked)

    def active_page(self):
        self.switch.size = 0
        self.switch.visible = False
        self.banner.visible = False

    def test_matching_page_actor_works_without_edit_button(self):
        self.active_page()
        self.page.context.cookies.return_value = [{"name": "i_user", "value": "1001"}]
        result = upload.ensure_page_identity(self.page, self.entry)
        self.assertEqual(result["method"], "page_actor_id_match")
        self.assertNotIn("1001", result["method"])

    def test_wrong_actor_is_rejected_even_with_active_header_control(self):
        self.active_page()
        self.edit.visible = True
        self.page.context.cookies.return_value = [{"name": "i_user", "value": "9999"}]
        with self.assertRaisesRegex(RuntimeError, "发布身份与目标公共主页不一致"):
            upload.prepare_reel(self.page, self.entry, None, "caption")
        self.assertFalse(any(call.args[0] == "form" for call in self.page.get_by_role.call_args_list))

    def test_cookies_and_credentials_are_not_in_result_or_output(self):
        self.active_page()
        self.page.context.cookies.return_value = [
            {"name": "i_user", "value": "1001"}, {"name": "xs", "value": "SESSION-SECRET"}]
        result = upload.ensure_page_identity(self.page, self.entry)
        self.assertNotIn("SESSION-SECRET", str(result))
        self.assertNotIn("SESSION-SECRET", self.silence._new_target.getvalue())

    def test_failed_local_cookie_read_does_not_expose_error_details(self):
        self.active_page()
        self.page.context.cookies.side_effect = RuntimeError("SESSION-SECRET")
        with self.assertRaisesRegex(RuntimeError, "无法在本地核对") as caught:
            upload.ensure_page_identity(self.page, self.entry)
        self.assertNotIn("SESSION-SECRET", str(caught.exception))


if __name__ == "__main__":
    unittest.main()
