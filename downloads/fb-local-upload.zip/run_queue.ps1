param([string]$Account = 'fb02', [string]$Target = 'page01')
$ErrorActionPreference = 'Stop'
$taskRoot = $PSScriptRoot
$pythonExe = Join-Path $taskRoot '.venv\Scripts\python.exe'
if (-not (Test-Path $pythonExe)) { throw "Python environment not found: $pythonExe" }
New-Item -ItemType Directory -Force -Path (Join-Path $taskRoot 'logs') | Out-Null
$env:PYTHONIOENCODING = 'utf-8'
$env:PYTHONUNBUFFERED = '1'
$logPath = Join-Path $taskRoot ('logs\run-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.log')
& $pythonExe (Join-Path $taskRoot 'fb_upload.py') publish --account $Account --target $Target 2>&1 | Tee-Object -FilePath $logPath
$taskExitCode = $LASTEXITCODE
exit $taskExitCode
