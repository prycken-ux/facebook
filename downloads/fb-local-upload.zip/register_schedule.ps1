param(
    [Parameter(Mandatory=$true)][string]$Time,
    [string]$Account = 'fb02',
    [string]$Target = 'page01'
)
$ErrorActionPreference = 'Stop'
if ($Time -notmatch '^([01][0-9]|2[0-3]):[0-5][0-9]$') { throw 'Time must be HH:mm, e.g. 09:00.' }
if ($Account -notmatch '^[A-Za-z0-9_-]+$' -or $Target -notmatch '^[A-Za-z0-9_-]+$') { throw 'Invalid account or target.' }
$configPath = Join-Path $PSScriptRoot 'upload_config.json'
$config = Get-Content -LiteralPath $configPath -Raw -Encoding UTF8 | ConvertFrom-Json
$entry = $config.targets | Where-Object { $_.account -eq $Account -and $_.target -eq $Target }
if (@($entry).Count -ne 1 -or -not $entry.enabled -or -not $entry.url) { throw 'Configure, prepare and enable this target first.' }
$taskName = "FBUpload-$Account-$Target"
if (Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue) { throw "Task already exists: $taskName. Edit it in Task Scheduler instead of overwriting it." }
$runner = Join-Path $PSScriptRoot 'run_queue.ps1'
$arguments = '-NoProfile -File "' + $runner + '" -Account ' + $Account + ' -Target ' + $Target
$action = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument $arguments -WorkingDirectory $PSScriptRoot
$trigger = New-ScheduledTaskTrigger -Daily -At $Time
$identity = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
$principal = New-ScheduledTaskPrincipal -UserId $identity -LogonType Interactive -RunLevel Limited
$settings = New-ScheduledTaskSettingsSet -MultipleInstances IgnoreNew -ExecutionTimeLimit (New-TimeSpan -Hours 2) -RunOnlyIfNetworkAvailable
Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger -Principal $principal -Settings $settings | Out-Null
Write-Host "Created $taskName at $Time in the Windows local time zone."
Write-Host 'Keep Windows signed in, unlocked and awake. One new video per run; errors stop for review.'
